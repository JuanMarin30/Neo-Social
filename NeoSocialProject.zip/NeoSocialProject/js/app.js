// Botón para ir al Registro
const goRegister = document.getElementById("goRegister");
if (goRegister) {
  goRegister.addEventListener("click", () => {
    window.location.href = "registro.html"; // usa el nombre real de tu archivo
  });
}

// Botón para ir a Recuperar Contraseña
const goRecover = document.getElementById("goRecover");
if (goRecover) {
  goRecover.addEventListener("click", () => {
    window.location.href = "recuperar.html"; // usa el nombre real de tu archivo
  });
}

// Acción al intentar iniciar sesión (LOGIN)
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    window.location.href = "home.html"; // redirige al dashboard
  });
}

// Acción del formulario de registro
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("Cuenta creada exitosamente (simulado)");
  });
}

// Acción del formulario de recuperación
const recoverForm = document.getElementById("recoverForm");
if (recoverForm) {
  recoverForm.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("Hemos enviado un enlace de recuperación a tu correo (simulado).");
  });
}

// Acción del formulario de contacto
const contactForm = document.getElementById("contactForm");
if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("Tu mensaje ha sido enviado. Gracias por contactarnos.");
  });
}

// ----- DASHBOARD -----
const titulo = document.getElementById("tituloSeccion");
const contenedor = document.getElementById("contenido");
const postsContainer = document.getElementById("postsContainer");

// Helper para cambiar secciones
function cargarSeccion(tituloTexto, contenidoHTML) {
  if (titulo) titulo.innerText = tituloTexto;
  if (contenedor) contenedor.innerHTML = contenidoHTML;
}

// Crear publicación
function crearPost(text, author = "Tú") {
  if (!text || !text.trim()) return;
  const post = document.createElement("div");
  post.className = "post card";
  post.innerHTML = `
    <div class="meta">
      <div class="author">
        <img src="https://via.placeholder.com/60" alt="user">
        <div>
          <div style="font-weight:700">${author}</div>
          <div class="small muted">Hace un momento</div>
        </div>
      </div>
      <div class="small">0 comentarios • <span class="badge">0</span></div>
    </div>
    <p style="margin-top:12px">${escapeHtml(text)}</p>
    <div class="reactions">
      <button class="likeBtn">❤️ Me gusta</button>
      <button class="commentBtn">💬 Comentar</button>
      <button class="shareBtn">🔗 Compartir</button>
    </div>
  `;
  if (postsContainer) postsContainer.prepend(post);

  post.querySelector(".likeBtn").onclick = () => {
    alert("Has reaccionado a la publicación (simulado).");
  };
}

// Escape básico para evitar inyección
function escapeHtml(text) {
  return text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

// Menú dinámico
if (document.getElementById("menuPerfil")) {
  document.getElementById("menuPerfil").onclick = () => {
    cargarSeccion("Perfil del Usuario", `
      <div class="card">
        <h3>Ver y Editar Perfil</h3>
        <p>Aquí puedes editar tu información personal.</p>
        <button id="editarPerfilBtn" class="btn btn-black">Editar perfil</button>
      </div>
    `);
    setTimeout(() => {
      const btn = document.getElementById("editarPerfilBtn");
      if (btn) btn.onclick = () => alert("Formulario de edición (simulado).");
    }, 100);
  };
}

if (document.getElementById("menuPublicar")) {
  document.getElementById("menuPublicar").onclick = () => {
    cargarSeccion("Publicar contenido", `
      <div class="card composer">
        <h3>Crear publicación</h3>
        <textarea id="composerText" style="width:100%;min-height:120px;"></textarea>
        <button id="btnPublish" class="btn btn-green">Publicar</button>
        <button id="btnReport" class="btn btn-red">Reportar</button>
      </div>
    `);
    setTimeout(() => {
      const btnPub = document.getElementById("btnPublish");
      if (btnPub) btnPub.onclick = () => {
        const t = document.getElementById("composerText").value;
        crearPost(t, "Tú");
        document.getElementById("composerText").value = "";
      };
      const btnRep = document.getElementById("btnReport");
      if (btnRep) btnRep.onclick = () => {
        const motivo = prompt("Describe la situación que quieres reportar:");
        if (motivo) alert("Reporte enviado (simulado).");
      };
    }, 100);
  };
}

if (document.getElementById("menuActividad")) {
  document.getElementById("menuActividad").onclick = () => {
    cargarSeccion("Actividad Reciente", `
      <div class="card">
        <h3>Actividad reciente</h3>
        <p>No hay actividad reciente todavía.</p>
      </div>
    `);
  };
}

if (document.getElementById("menuChat")) {
  document.getElementById("menuChat").onclick = () => {
    cargarSeccion("Chat / Mensajería Directa", `
      <div class="card">
        <h3>Chat en construcción...</h3>
      </div>
    `);
  };
}

if (document.getElementById("menuAyuda")) {
  document.getElementById("menuAyuda").onclick = () => {
    cargarSeccion("Chat de Ayuda", `
      <div class="card">
        <h3>Ayuda en línea</h3>
        <input placeholder="Escribe tu mensaje..." style="width:100%;padding:10px;">
      </div>
    `);
  };
}

if (document.getElementById("menuEventos")) {
  document.getElementById("menuEventos").onclick = () => {
    cargarSeccion("Eventos y Alertas", `
      <div class="card">
        <h3>Eventos</h3>
        <p>No hay eventos por ahora.</p>
      </div>
    `);
  };
}

if (document.getElementById("menuNotificaciones")) {
  document.getElementById("menuNotificaciones").onclick = () => {
    cargarSeccion("Centro de Notificaciones", `
      <div class="card">
        <h3>Notificaciones</h3>
        <p>No tienes notificaciones nuevas.</p>
      </div>
    `);
  };
}

// Contador de notificaciones
const notifCount = document.getElementById("notifCount");
if (notifCount) {
  notifCount.innerText = "2";
}
